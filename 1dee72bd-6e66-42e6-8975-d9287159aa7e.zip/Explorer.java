import java.util.Scanner;

public class Explorer {
   public static void main(String[] args) {

      /* Type your code here. */
      
   }
}
